class PagesController < ApplicationController
  def home
  end
  
  def upload
  end

  def recipes
  	
  end
end
