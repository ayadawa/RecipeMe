Rails.application.routes.draw do
  
  post '/rate' => 'rater#create', :as => 'rate'
  devise_for :users
 root "pages#home" 
 get "contact" => "pages#contact"

resources :pins do 
  resources :comments
  end

  resources :comments do
    resources :comments
  end
 get "upload" => "pages#upload"
  resources :recipes
  get 'recipes/index'

  get 'recipes/new'

  get 'recipes/create'

  get 'recipes/show'

  # For details on the DSL available within this file, see http://guides.rubyonrails.org/routing.html
end
